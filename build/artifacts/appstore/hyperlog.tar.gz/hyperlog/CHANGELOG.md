owncloud-hyperlog (0.0.1)
* **Security**: Security description here
* **Backwards incompatible change**: Changes in the API
* **New dependency**: New dependencies such as a new ownCloud or PHP version
* **Bugfix**: Bugfix description
* **Enhancement**: New feature description