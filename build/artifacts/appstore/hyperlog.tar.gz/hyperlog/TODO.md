# TODO

* [x] Admin settings screen
    * [ ] Custom logging destinations, e.g. MySQL, Redis, third-party services
* [x] save configuration in YAML or database table
* [ ] l10n
* [ ] write tests
* [ ] fix doubled log messages bug
* [ ] Admin option for download logging